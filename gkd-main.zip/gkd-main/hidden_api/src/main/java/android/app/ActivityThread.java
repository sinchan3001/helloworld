package android.app;

@SuppressWarnings("unused")
public class ActivityThread {

    public static ActivityThread currentActivityThread() {
        throw new RuntimeException("Stub!");
    }

    public ContextImpl getSystemContext() {
        throw new RuntimeException("Stub!");
    }
}
