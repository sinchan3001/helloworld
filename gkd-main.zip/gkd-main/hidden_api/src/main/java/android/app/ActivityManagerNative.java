package android.app;

import android.os.IBinder;

@SuppressWarnings("unused")
public class ActivityManagerNative {

    public static IActivityManager asInterface(IBinder obj) {
        throw new RuntimeException("Stub!");
    }
}
