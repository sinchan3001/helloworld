package android.app;

import android.content.Context;

@SuppressWarnings("unused")
public abstract class ContextImpl extends Context {

}
