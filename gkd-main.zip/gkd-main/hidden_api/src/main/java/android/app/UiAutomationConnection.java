
package android.app;

@SuppressWarnings("unused")
public class UiAutomationConnection extends IUiAutomationConnection.Default {
    public UiAutomationConnection() {
        throw new RuntimeException("Stub!");
    }
}
