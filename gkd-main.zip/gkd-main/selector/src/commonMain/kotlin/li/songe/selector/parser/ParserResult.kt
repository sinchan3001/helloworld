package li.songe.selector.parser

internal data class ParserResult<T>(val data: T, val length: Int = 0)
