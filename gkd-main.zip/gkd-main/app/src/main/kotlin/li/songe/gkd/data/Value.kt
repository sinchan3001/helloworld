package li.songe.gkd.data

class Value<T>(var value: T)