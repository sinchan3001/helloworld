package li.songe.gkd.data

import kotlinx.serialization.Serializable

@Serializable
data class SubsVersion(val id: Long, val version: Int)
