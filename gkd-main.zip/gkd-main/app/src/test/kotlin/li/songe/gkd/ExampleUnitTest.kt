package li.songe.gkd

import org.junit.Test

class ExampleUnitTest {

    @Test
    fun test() {
    }

}