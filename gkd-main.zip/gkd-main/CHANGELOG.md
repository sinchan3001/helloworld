# v1.9.2

以下是本次更新的主要内容

## 优化和修复

- 优化关于界面布局
- 优化上传文件的逻辑
- 优化规则匹配逻辑
- 优化显示透明导航栏
- 修复HTTP服务启动失败的问题
- 其它优化和错误修复

## 通过以下任意方式更新

- 打开 APP - 设置 - 检测更新
- 前往首页 <https://gkd.li/guide/>
- 通过 github [releases](https://github.com/gkd-kit/gkd/releases)
